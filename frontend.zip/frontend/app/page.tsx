import { Landing } from "@/components/component/landing";

export default function Page() {
  return <Landing />;
}
